5001	5001	HEDNO_commercial_MV_5001	Μ.Τ. Περ. Φιλοθέης	102
5002	5002	HEDNO_commercial_MV_5002	Μ.Τ Περ. Περιστερίου	102
5003	5003	HEDNO_commercial_MV_5003	Κοζάνης	102
5004	5004	HEDNO_commercial_MV_5004	Μ.Τ Περ. Αθηνών	102
5005	5005	HEDNO_commercial_MV_5005	Πτολεμαϊδας	102
5006	5006	HEDNO_commercial_MV_5006	Κοζάνης	102
5007	5007	HEDNO_commercial_MV_5007	Κοζάνης	102
5008	5008	HEDNO_commercial_MV_5008	Μ.Τ Περ. Αθηνών	102
5009	5009	HEDNO_commercial_MV_5009	Μ.Τ. Περ. Φιλοθέης	102
5010	5010	HEDNO_commercial_MV_5010	Πάτρας	102
5011	5011	HEDNO_commercial_MV_5011	Μ.Τ. Περ. Φιλοθέης	102
5012	5012	HEDNO_commercial_MV_5012	Μ.Τ Περ. Αθηνών	102
5013	5013	HEDNO_commercial_MV_5013	Καρδίτσας	102
5014	5014	HEDNO_commercial_MV_5014	Καρδίτσας	102
5015	5015	HEDNO_commercial_MV_5015	Μ.Τ Περ. Αθηνών	102
5016	5016	HEDNO_commercial_MV_5016	Μ.Τ Περ. Αθηνών	102
5017	5017	HEDNO_commercial_MV_5017	Μ.Τ Περ. Πειραιώς	102
5018	5018	HEDNO_commercial_MV_5018	Μ.Τ Περ. Πειραιώς	102
5019	5019	HEDNO_commercial_MV_5019	Μ.Τ Περ. Πειραιώς	102
5020	5020	HEDNO_commercial_MV_5020	Μ.Τ Περ. Πειραιώς	102
5021	5021	HEDNO_commercial_MV_5021	Κεντρ. Θεσ/κης	102
5022	5022	HEDNO_commercial_MV_5022	Κεντρ. Θεσ/κης	102
5023	5023	HEDNO_commercial_MV_5023	Κεντρ. Θεσ/κης	102
5024	5024	HEDNO_commercial_MV_5024	Κεντρ. Θεσ/κης	102
5025	5025	HEDNO_commercial_MV_5025	Κεντρ. Θεσ/κης	102
5026	5026	HEDNO_commercial_MV_5026	Κεντρ. Θεσ/κης	102
5027	5027	HEDNO_commercial_MV_5027	Κεντρ. Θεσ/κης	102
5028	5028	HEDNO_commercial_MV_5028	Κεντρ. Θεσ/κης	102
5029	5029	HEDNO_commercial_MV_5029	Κεντρ. Θεσ/κης	102
5030	5030	HEDNO_commercial_MV_5030	Πτολεμαϊδας	102
5031	5031	HEDNO_commercial_MV_5031	Μ.Τ Περ. Πειραιώς	102
5032	5032	HEDNO_commercial_MV_5032	Καρδίτσας	102
5033	5033	HEDNO_commercial_MV_5033	Μ.Τ. Περ. Φιλοθέης	102
5034	5034	HEDNO_commercial_MV_5034	Πάτρας	102
5035	5035	HEDNO_commercial_MV_5035	Μ.Τ Περ. Περιστερίου	102
5036	5036	HEDNO_commercial_MV_5036	Πάτρας	102
5037	5037	HEDNO_commercial_MV_5037	Πάτρας	102
5038	5038	HEDNO_commercial_MV_5038	Πάτρας	102
5039	5039	HEDNO_commercial_MV_5039	Μ.Τ Περ. Περιστερίου	102
5040	5040	HEDNO_commercial_MV_5040	Μ.Τ Περ. Περιστερίου	102
5041	5041	HEDNO_commercial_MV_5041	Πάτρας	102
5042	5042	HEDNO_commercial_MV_5042	Μ.Τ. Περ. Φιλοθέης	102
5043	5043	HEDNO_commercial_MV_5043	Πτολεμαϊδας	102
5044	5044	HEDNO_commercial_MV_5044	Κοζάνης	102
5045	5045	HEDNO_commercial_MV_5045	Καρδίτσας	102
5046	5046	HEDNO_commercial_MV_5046	Μ.Τ. Περ. Φιλοθέης	102
5047	5047	HEDNO_commercial_MV_5047	Κεντρ. Θεσ/κης	102
5048	5048	HEDNO_commercial_MV_5048	Μ.Τ. Περ. Φιλοθέης	102
5049	5049	HEDNO_commercial_MV_5049	Μ.Τ Περ. Πειραιώς	102
5050	5050	HEDNO_commercial_MV_5050	Μ.Τ Περ. Αθηνών	102
