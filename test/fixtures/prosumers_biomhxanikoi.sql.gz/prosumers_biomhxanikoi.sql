6001	6001	HEDNO_biomhxanikoi_6001	Δυτ. Θεσ/κης	101
6002	6002	HEDNO_biomhxanikoi_6002	Λαυρίου	101
6003	6003	HEDNO_biomhxanikoi_6003	Δυτ. Θεσ/κης	101
6004	6004	HEDNO_biomhxanikoi_6004	Κορωπίου	101
6005	6005	HEDNO_biomhxanikoi_6005	Δυτ. Θεσ/κης	101
6006	6006	HEDNO_biomhxanikoi_6006	Χαλκίδας	101
6007	6007	HEDNO_biomhxanikoi_6007	Δυτ. Θεσ/κης	101
6008	6008	HEDNO_biomhxanikoi_6008	Δυτ. Θεσ/κης	101
6009	6009	HEDNO_biomhxanikoi_6009	Δυτ. Θεσ/κης	101
6010	6010	HEDNO_biomhxanikoi_6010	Καβάλας	101
6011	6011	HEDNO_biomhxanikoi_6011	Ορεστιάδας	101
6012	6012	HEDNO_biomhxanikoi_6012	Αιγίου	101
6013	6013	HEDNO_biomhxanikoi_6013	Φλώρινας	101
6014	6014	HEDNO_biomhxanikoi_6014	Δυτ. Θεσ/κης	101
6015	6015	HEDNO_biomhxanikoi_6015	Αιγάλεω	101
6016	6016	HEDNO_biomhxanikoi_6016	Αιγάλεω	101
6017	6017	HEDNO_biomhxanikoi_6017	Κορωπίου	101
6018	6018	HEDNO_biomhxanikoi_6018	Δυτ. Θεσ/κης	101
6019	6019	HEDNO_biomhxanikoi_6019	Βόλου	101
6020	6020	HEDNO_biomhxanikoi_6020	Αγρινίου	101
6021	6021	HEDNO_biomhxanikoi_6021	Δυτ. Θεσ/κης	101
6022	6022	HEDNO_biomhxanikoi_6022	Κορωπίου	101
6023	6023	HEDNO_biomhxanikoi_6023	Αιγίου	101
6024	6024	HEDNO_biomhxanikoi_6024	Λαυρίου	101
6025	6025	HEDNO_biomhxanikoi_6025	Δυτ. Θεσ/κης	101
6026	6026	HEDNO_biomhxanikoi_6026	Δυτ. Θεσ/κης	101
6027	6027	HEDNO_biomhxanikoi_6027	Δυτ. Θεσ/κης	101
6028	6028	HEDNO_biomhxanikoi_6028	Δυτ. Θεσ/κης	101
6029	6029	HEDNO_biomhxanikoi_6029	Πάτρας	101
6030	6030	HEDNO_biomhxanikoi_6030	Δυτ. Θεσ/κης	101
6031	6031	HEDNO_biomhxanikoi_6031	Δυτ. Θεσ/κης	101
6032	6032	HEDNO_biomhxanikoi_6032	Δυτ. Θεσ/κης	101
6033	6033	HEDNO_biomhxanikoi_6033	Δυτ. Θεσ/κης	101
6034	6034	HEDNO_biomhxanikoi_6034	Αλιβερίου	101
6035	6035	HEDNO_biomhxanikoi_6035	Δυτ. Θεσ/κης	101
6036	6036	HEDNO_biomhxanikoi_6036	Κορωπίου	101
6037	6037	HEDNO_biomhxanikoi_6037	Δυτ. Θεσ/κης	101
6038	6038	HEDNO_biomhxanikoi_6038	Κορωπίου	101
6039	6039	HEDNO_biomhxanikoi_6039	Κ.Αχαϊας	101
6040	6040	HEDNO_biomhxanikoi_6040	Δυτ. Θεσ/κης	101
6041	6041	HEDNO_biomhxanikoi_6041	Περιστερίου	101
6042	6042	HEDNO_biomhxanikoi_6042	Πάτρας	101
6043	6043	HEDNO_biomhxanikoi_6043	Λαυρίου	101
6044	6044	HEDNO_biomhxanikoi_6044	Δυτ. Θεσ/κης	101
6045	6045	HEDNO_biomhxanikoi_6045	Δυτ. Θεσ/κης	101
6046	6046	HEDNO_biomhxanikoi_6046	Δυτ. Θεσ/κης	101
6047	6047	HEDNO_biomhxanikoi_6047	Κορωπίου	101
6048	6048	HEDNO_biomhxanikoi_6048	Αιγάλεω	101
6049	6049	HEDNO_biomhxanikoi_6049	Δυτ. Θεσ/κης	101
6050	6050	HEDNO_biomhxanikoi_6050	Δυτ. Θεσ/κης	101
